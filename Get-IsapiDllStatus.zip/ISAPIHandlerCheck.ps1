$Creds = Get-Credential

# Import servers here
$Servers = Get-Content .\Servers.txt

# Create csv file of all websites that have ISAPI-Dll enabled (Execute)
$Servers | Get-IsapiDllStatus -Credential $Creds| Where-Object {$_.AccessPolicy -match "Execute"} | Export-Csv -Path "IsapiReport.csv" -Force -NoTypeInformation